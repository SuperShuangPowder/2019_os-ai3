package a_star_search;
import java.awt.*;
	import javax.swing.JButton;
	import javax.swing.JCheckBox;
	import javax.swing.JFrame;
	import javax.swing.JLabel;
	import javax.swing.JPasswordField;
	import javax.swing.JTextField;

	import javax.swing.JPanel;

	public class Login {
		public static void main (String[] args){
		Login IA= new Login();
		IA.showUI();
		}
		
		
		
		public void showUI(){
			JFrame jf=new JFrame();
			jf.setTitle("QQ��½����");
			jf.setSize(400,400);
			//���̹ر�
			jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			FlowLayout fl=new FlowLayout();
			
			jf.setLayout(fl);
			
			jf.setLocationRelativeTo(null);
			
			jf.setResizable(false);
			
		//	lmagelcon imagelcon= new lmagelcon("D:\\��������png");
		//	JLabel jlb=new JLabel(imagelcon);
			JLabel name= new JLabel("QQ����");
			JButton b1 =new JButton("�������");
			JLabel password= new JLabel("QQ����");
			
			Dimension mansion=new Dimension(250,20);
			
			JTextField jt=new JTextField();
			JPasswordField jpassword=new JPasswordField();
			JButton b2 =new JButton("��������");
			JButton btn1 =new JButton("��½");
			JButton btn2 =new JButton("ȡ��");
			JButton btn3 =new JButton("ע����");
			
			Dimension dimension=new Dimension(100,40);
			Dimension q=new Dimension(100,20);
			JCheckBox jcbox1=new JCheckBox("������½");
			JCheckBox jcbox2=new JCheckBox("�Զ���½");
			JCheckBox jcbox3=new JCheckBox("��ס����");
			
			jcbox1.setPreferredSize(q);
			jcbox2.setPreferredSize(q);
			jcbox3.setPreferredSize(q);
			
			jt.setPreferredSize(mansion);
		/*	btn.setBackground(new Color(7,189,253));*/
			jpassword.setPreferredSize(mansion);
			btn1.setPreferredSize(dimension);
			btn2.setPreferredSize(dimension);
			btn3.setPreferredSize(dimension);
		//	jf.add(jlb);
			jf.add(name);
			jf.add(jt);
			jf.add(b1);
			
			jf.add(password);
			
			jf.add(jpassword);
			jf.add(b2);
			jf.add(jcbox1);
			jf.add(jcbox2);
			jf.add(jcbox3);
		//	jf.add(find);
			jf.add(btn1);
			jf.add(btn2);
			jf.add(btn3);
			jf.setVisible(true);
		}

}
