package a_star_search;

	import java.util.Scanner;
	import java.util.Stack;
	 
	public class Test {
		private static String Str = null; // ���봮
		private static String Sub = null; //���봮�Ĵ���������
		private static boolean acc = false;// �Ƿ��Ѵ��������봮
		private static boolean bResult = false;// �Ƿ����
	 
		// Goto������ÿ��״̬�������ս��ʱ�Ķ���
		private static int[][] Goto = new int[][] { { 1, 2, 3 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 }, { 8, 2, 3 },
				{ 0, 0, 0 }, { 0, 9, 3 }, { 0, 0, 10 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 } }; 
				
	 
		private static Stack<String> stack = new Stack<String>();// ״̬ջ��ջ��Ԫ�ض���String����
	 
		/**
		 * 
		 * @param state ״̬
		 * @param fzjf �����ķ��ս��
		 * fzjf == 'E'������Goto���ĵ�һ��
		 * fzjf == 'T'������Goto���ĵڶ���
		 * fzjf == 'F'������Goto���ĵ�����
		 */
		public static void Gto(int state, char fzjf) {
			int i = -1;
			if (fzjf == 'E')
				i = 0;
			if (fzjf == 'T')
				i = 1;
			if (fzjf == 'F')
				i = 2;
	 
			stack.push(fzjf + ""); //�����ս��ѹ��ջ�У��ַ�+�մ�ת��Ϊ�ַ���
			stack.push(Goto[state][i] + "");//��Goto���ж�Ӧ��״̬ѹ��ջ��
	 
		}
	 
		/**
		 * e1����ȱ��������� ����id��ѹ��ջ�У��漴����Ӧ��״̬ѹ��ջ��
		 * 
		 */
		public static void e1() {
			System.out.println("ȱ���������");
			stack.push("id");
			stack.push(String.valueOf(3));
//			bResult = true;
	//�����в�ע�͵������������������ͻ�����ֹͣ	����ע�͵������򲻻�����ֹͣ�����ǻ�ָ�����	
		}
	 
		public static void e3() {
			System.out.println("ȱ�����");
			stack.push("+");
			stack.push("" + 6);
//			bResult = true;
		}
	 
		public static void e3_() {
			System.out.println("ȱ�����");
			stack.push("*");
			stack.push("" + 7);
//			bResult = true;
		}
	 
		public static void e2() {
			System.out.println("��ƥ���������");
			Sub = Sub.substring(1, Sub.length());
//			bResult = true;
		}
	 
		public static void e4() {
			System.out.println("ȱ��������");
			stack.push("");
			stack.push(11 + "");
//			bResult = true;
		}
	 
		public static void e5() {
			System.out.println("�������");
			stack.push("+");
			stack.push(6 + "");
			Sub = Sub.substring(1, Sub.length());
//			bResult = true;
		}
	 
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.out.println("�����봮��");
			Scanner in = new Scanner(System.in);
			Str = in.nextLine();
			Sub = Str;   //��ʼʱSub = Str
			in.close();
	 
			int y;
			boolean flag = false;
	 
			// 0״̬�Ƚ�ջ
			stack.push(String.valueOf(0));
			while (!bResult && acc == false) {
				switch (stack.peek().charAt(0)) {
				case '0':
					if (Sub.substring(0, 2).equals("id")) {
						stack.push("id");
						stack.push("" + 5);
						Sub = Sub.substring(2, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals("(")) {
						stack.push("(");
						stack.push("" + 4);
						Sub = Sub.substring(1, Sub.length());
						System.out.println("�ƽ�");
					} else {
						e1();
					}
					break;
				case '1':
					if ("1".equals(stack.peek())) {
						if (Sub.substring(0, 1).equals("+")) {
							stack.push("id");
							stack.push("" + 6);
							Sub = Sub.substring(1, Sub.length());
							System.out.println("�ƽ�");
						} else if (Sub.substring(0, 1).equals("#")) {
							acc = true;
							System.out.println("����");
						} else {
							e3();
						}
						break;
					} else if (stack.peek().charAt(1) == '0') {
						if (Sub.substring(0, 1).equals("+")) {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
							System.out.println("��T->T*F��Լ");
						} else if (Sub.substring(0, 1).equals(")")) {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
							System.out.println("��T->T*F��Լ");
						} else if (Sub.substring(0, 1).equals("#")) {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
							System.out.println("��T->T*F��Լ");
						} else if (Sub.substring(0, 1).equals("*")) {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
							System.out.println("��T->T*F��Լ");
						} else {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
							System.out.println("��T->T*F��Լ");
						}
						break;
					} else {
						if (Sub.substring(0, 1).equals("+")) {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
							System.out.println("��F->(E)��Լ");
						} else if (Sub.substring(0, 1).equals(")")) {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
							System.out.println("��F->(E)��Լ");
						} else if (Sub.substring(0, 1).equals("#")) {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
							System.out.println("��F->(E)��Լ");
						} else if (Sub.substring(0, 1).equals("*")) {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
							System.out.println("��F->(E)��Լ");
						} else {
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							stack.pop();
							Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
							System.out.println("��F->(E)��Լ");
						}
						break;
					}
				case '2':
					if (Sub.substring(0, 1).equals("*")) {
						stack.push("*");
						stack.push("" + 7);
						Sub = Sub.substring(1, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals("+")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'E');
						System.out.println("��E->T��Լ");
					} else if (Sub.substring(0, 1).equals(")")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'E');
						System.out.println("��E->T��Լ");
					} else if (Sub.substring(0, 1).equals("#")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'E');
						System.out.println("��E->T��Լ");
					} else {
						e3_();
					}
					break;
				case '3':
					if (Sub.substring(0, 1).equals("+")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
						System.out.println("��T->F��Լ");
					} else if (Sub.substring(0, 1).equals(")")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
						System.out.println("��T->F��Լ");
					} else if (Sub.substring(0, 1).equals("#")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
						System.out.println("��T->F��Լ");
					} else if (Sub.substring(0, 1).equals("*")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
						System.out.println("��T->F��Լ");
					} else {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'T');
						System.out.println("��T->F��Լ");
					}
					break;
				case '4':
					if (Sub.substring(0, 2).equals("id")) {
						stack.push("id");
						stack.push("" + 5);
						Sub = Sub.substring(2, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals("(")) {
						stack.push("(");
						stack.push("" + 4);
						Sub = Sub.substring(1, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals(")")) {
						e2();
					} else
						e1();
					break;
				case '5':
					if (Sub.substring(0, 1).equals("+")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
						System.out.println("��F->id��Լ");
					} else if (Sub.substring(0, 1).equals(")")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
						System.out.println("��F->id��Լ");
					} else if (Sub.substring(0, 1).equals("#")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
						System.out.println("��F->id��Լ");
					} else if (Sub.substring(0, 1).equals("*")) {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
						System.out.println("��F->id��Լ");
					} else {
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'F');
						System.out.println("��F->id��Լ");
					}
					break;
				case '6':
					if (Sub.length() > 1) {
						if (Sub.substring(0, 1).equals("(")) {
							stack.push("(");
							stack.push("" + 4);
							Sub = Sub.substring(1, Sub.length());
							System.out.println("�ƽ�");
						} else if (Sub.substring(0, 2).equals("id")) {
							stack.push("id");
							stack.push("" + 5);
							Sub = Sub.substring(2, Sub.length());
							System.out.println("�ƽ�");
						} else if (Sub.substring(0, 1).equals(")")) {
							e2();
						}
					} else
						e1();
					break;
				case '7':
					if (Sub.substring(0, 2).equals("id")) {
						stack.push("id");
						stack.push("" + 5);
						Sub = Sub.substring(2, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals("(")) {
						stack.push("(");
						stack.push("" + 4);
						Sub = Sub.substring(1, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals("(")) {
						stack.push("(");
						stack.push("" + 4);
						Sub = Sub.substring(1, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals(")")) {
						e2();
					} else
						e1();
					break;
				case '8':
					if (Sub.substring(0, 1).equals("+")) {
						stack.push("+");
						stack.push("" + 6);
						Sub = Sub.substring(1, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals(")")) {
						stack.push(")");
						stack.push("" + 11);
						Sub = Sub.substring(1, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals("#")) {
						e4();
					} else if (Sub.substring(0, 1).equals("*")) {
						e5();
					} else
						e3();
					break;
				case '9':
					if (Sub.substring(0, 1).equals("*")) {
						stack.push("*");
						stack.push("" + 7);
						Sub = Sub.substring(1, Sub.length());
						System.out.println("�ƽ�");
					} else if (Sub.substring(0, 1).equals("+")) {
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'E');
						System.out.println("��E->E+T��Լ");
					} else if (Sub.substring(0, 1).equals(")")) {
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'E');
						System.out.println("��E->E+T��Լ");
					} else if (Sub.substring(0, 1).equals("#")) {
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'E');
						System.out.println("��E->E+T��Լ");
					} else {
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						stack.pop();
						Gto((int) stack.peek().charAt(0) - (int) '0', 'E');
						System.out.println("��E->E+T��Լ");
					}
					break;
	 
				}
	 
			}
			if (acc)
	 
			{
				System.out.println("ƥ��ɹ�");
			}
	 
		}
}
